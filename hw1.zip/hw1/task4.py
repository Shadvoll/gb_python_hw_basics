cranes = int(input("Введите количество журавликов: "))
base = cranes // 6
print(base, 4*base, base)
